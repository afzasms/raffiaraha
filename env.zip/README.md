# بافت‌رافیا‌راه | RaffiAraha

فروشگاه آنلاین صنایع دستی اصیل ایرانی

---

## 🌐 اطلاعات دامنه

| مورد | مقدار |
|------|-------|
| دامنه اصلی | https://raffiaraha.ir |
| برند فارسی | بافت‌رافیا‌راه |
| برند لاتین | RaffiAraha |
| ایمیل | info@raffiaraha.ir |

---

## 🧱 استک فنی

- **فرانت‌اند:** Next.js 14 (App Router) + TypeScript
- **استایل:** TailwindCSS 3.4 + RTL
- **فونت:** Vazirmatn (آفلاین)
- **آیکون:** Lucide React
- **مدیریت State:** Zustand
- **فرم:** React Hook Form + Zod
- **Fetch داده:** TanStack Query
- **بک‌اند:** NestJS (گام ۷)
- **دیتابیس:** PostgreSQL + Prisma ORM
- **ذخیره‌سازی:** S3 / MinIO
- **Auth:** JWT + Refresh Token + 2FA

---

## 📂 ساختار پروژه
