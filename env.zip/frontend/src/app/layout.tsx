import type { Metadata, Viewport } from 'next';
import './globals.css';

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://raffiaraha.ir';
const SITE_NAME = process.env.NEXT_PUBLIC_SITE_NAME || 'بافت‌رافیا‌راه';

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${SITE_NAME} | فروشگاه آنلاین صنایع دستی ایرانی`,
    template: `%s | ${SITE_NAME}`,
  },
  description:
    'خرید آنلاین صنایع دستی اصیل ایرانی؛ فرش دستباف، سفال، چوب، فلز و شیشه با ضمانت اصالت و ارسال امن به سراسر کشور.',
  keywords: [
    'صنایع دستی',
    'خرید صنایع دستی',
    'فروشگاه صنایع دستی',
    'فرش دستباف',
    'سفال handmade',
    'صنایع چوبی',
    'بافت‌رافیا‌راه',
  ],
  authors: [{ name: 'بافت‌رافیا‌راه', url: SITE_URL }],
  creator: 'بافت‌رافیا‌راه',
  publisher: 'بافت‌رافیا‌راه',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'fa_IR',
    url: SITE_URL,
    siteName: SITE_NAME,
    title: `${SITE_NAME} | فروشگاه صنایع دستی ایرانی`,
    description: 'اصیل‌ترین صنایع دستی ایرانی با ضمانت اصالت',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: SITE_NAME,
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: SITE_NAME,
    description: 'فروشگاه صنایع دستی ایرانی',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
  alternates: {
    canonical: SITE_URL,
  },
};

export const viewport: Viewport = {
  themeColor: '#16a34a',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <link
          rel="preload"
          href="/fonts/Vazirmatn-Regular.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
        <link
          rel="preload"
          href="/fonts/Vazirmatn-Bold.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
      </head>
      <body className="font-vazir min-h-screen">
        {children}
      </body>
    </html>
  );
}