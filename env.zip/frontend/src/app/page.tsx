import { ShoppingBag, Sparkles, CheckCircle2 } from 'lucide-react';

export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-50 via-white to-action-50 p-4">
      <div className="text-center space-y-8 animate-fade-in max-w-2xl">
        {/* بج بالای صفحه */}
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-100 text-brand-700 rounded-full">
          <Sparkles className="w-5 h-5" />
          <span className="text-sm font-medium">نسخه آزمایشی</span>
        </div>

        {/* عنوان اصلی */}
        <h1 className="text-5xl md:text-7xl font-black text-gray-900 tracking-tight">
          بافت‌رافیا‌راه
        </h1>

        {/* توضیح */}
        <p className="text-xl md:text-2xl text-gray-600 max-w-xl mx-auto leading-relaxed">
          فروشگاه آنلاین صنایع دستی اصیل ایرانی
        </p>

        {/* ویژگی‌ها */}
        <div className="flex flex-wrap gap-3 justify-center pt-2">
          {[
            'ضمانت اصالت کالا',
            'ارسال امن به سراسر کشور',
            'پرداخت آنلاین امن',
            'پشتیبانی ۲۴/۷',
          ].map((feature) => (
            <div
              key={feature}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white rounded-xl shadow-card text-sm text-gray-700"
            >
              <CheckCircle2 className="w-4 h-4 text-brand-600" />
              {feature}
            </div>
          ))}
        </div>

        {/* دکمه‌ها */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
          <button className="btn-primary text-lg px-8 py-3.5">
            <ShoppingBag className="w-5 h-5" />
            ورود به فروشگاه
          </button>
          <button className="btn-outline text-lg px-8 py-3.5">
            درباره ما
          </button>
        </div>

        {/* وضعیت */}
        <div className="pt-12 text-sm text-gray-400 flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-brand-500" />
          گام ۲ با موفقیت اجرا شد
        </div>

        {/* نسخه */}
        <div className="text-xs text-gray-300">
          RaffiAraha v1.0.0
        </div>
      </div>
    </main>
  );
}