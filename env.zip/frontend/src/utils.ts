import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * ترکیب هوشمند کلاس‌های Tailwind
 * با حل تعارض‌ها (کلاس آخر برنده است)
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * تبدیل اعداد لاتین به فارسی
 */
export function toPersianDigits(input: string | number): string {
  const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(input).replace(/\d/g, (d) => fa[+d]);
}

/**
 * فرمت قیمت با جداکننده هزارگان و واحد تومان
 */
export function formatPrice(price: number): string {
  return toPersianDigits(price.toLocaleString('en-US')) + ' تومان';
}

/**
 * اسلاگ‌سازی متن فارسی برای URL
 */
export function slugify(text: string): string {
  return text
    .trim()
    .replace(/[\s_]+/g, '-')
    .replace(/[^\u0600-\u06FF\w-]/g, '')
    .toLowerCase();
}

/**
 * محاسبه درصد تخفیف
 */
export function discountPercent(price: number, discountPrice: number): number {
  if (!discountPrice || discountPrice >= price) return 0;
  return Math.round(((price - discountPrice) / price) * 100);
}

/**
 * کوتاه کردن متن طولانی
 */
export function truncate(text: string, length: number): string {
  if (text.length <= length) return text;
  return text.slice(0, length).trim() + '...';
}

/**
 * تاخیر (برای تست)
 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}