// ========================================
// RaffiAraha - TypeScript Types
// ========================================

// ===== محصول =====
export type Product = {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  price: number;
  discountPrice?: number;
  stock: number;
  sku: string;
  images: string[];
  thumbnail: string;
  rating: number;
  reviewsCount: number;
  categoryId: string;
  category?: Category;
  artisanId?: string;
  artisan?: Artisan;
  tags: string[];
  isActive: boolean;
  isFeatured: boolean;
  createdAt: string;
  updatedAt: string;
};

// ===== دسته‌بندی =====
export type Category = {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  image?: string;
  parentId?: string | null;
  children?: Category[];
  productsCount?: number;
};

// ===== هنرمند =====
export type Artisan = {
  id: string;
  name: string;
  slug: string;
  bio?: string;
  avatar?: string;
  city?: string;
  specialty?: string;
};

// ===== سبد خرید =====
export type CartItem = {
  productId: string;
  product: Product;
  quantity: number;
  selectedOptions?: Record<string, string>;
};

export type Cart = {
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
};

// ===== کاربر =====
export type User = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: 'user' | 'admin' | 'artisan';
  avatar?: string;
  addresses?: Address[];
  createdAt: string;
};

// ===== آدرس =====
export type Address = {
  id: string;
  title: string;
  province: string;
  city: string;
  postalCode: string;
  fullAddress: string;
  isDefault: boolean;
};

// ===== سفارش =====
export type Order = {
  id: string;
  orderNumber: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: OrderStatus;
  shippingAddress: Address;
  paymentMethod: 'online' | 'cod';
  paymentStatus: 'pending' | 'paid' | 'failed';
  trackingCode?: string;
  createdAt: string;
};

export type OrderStatus =
  | 'pending'
  | 'paid'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

// ===== کوپن =====
export type Coupon = {
  code: string;
  type: 'percent' | 'fixed';
  value: number;
  minOrder?: number;
  expiresAt: string;
};

// ===== API Response =====
export type ApiResponse<T> = {
  success: boolean;
  data: T;
  message?: string;
};

export type PaginatedResponse<T> = {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
};

// ===== فیلتر محصولات =====
export type ProductFilter = {
  categoryId?: string;
  minPrice?: number;
  maxPrice?: number;
  rating?: number;
  inStock?: boolean;
  search?: string;
  sortBy?: 'newest' | 'cheapest' | 'expensive' | 'popular';
  page?: number;
  pageSize?: number;
};